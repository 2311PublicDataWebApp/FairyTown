package com.ajoo.boottwo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AjooBootTwoApplicationTests {

	@Test
	void contextLoads() {
	}

}
