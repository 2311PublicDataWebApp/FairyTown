package com.ajoo.boottwo.notice.store;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.apache.ibatis.session.RowBounds;

import com.ajoo.boottwo.domain.vo.NoticeVO;

@Mapper // 매퍼 (dependency 추가 필요)
public interface NoticeStore {
	// Mybatis Spring Boot Starter 가 해주는 것
	// 1. 존재하는 Datasource를 자동으로 찾아서 사용
	// 2. 연결도 자동으로 만들어줌(SqlSession)
	// 3. 자동으로 Mapper를 스캔해서 해당 쿼리문 실행해줌
		
	@Insert("INSERT INTO NOTICE_TBL VALUES(SEQ_NOTICE_NO.NEXTVAL, #{noticeSubject},#{noticeContent},#{noticeWriter},DEFAULT,DEFAULT,NULL,NULL,NULL,NULL)") // 쿼리문
	int insertNotice(NoticeVO notice);

	@Update("UPDATE NOTICE_TBL SET NOTICE_SUBJECT=#{noticeSubject}, NOTICE_CONTENT=#{noticeContent} WHERE NOTICE_NO=#{noticeNo}")
	int updateNotice(NoticeVO notice);

	@Delete("DELETE FROM NOTICE_TBL WHERE NOTICE_NO=#{noticeNo }")
	int deleteNotice(Integer noticeNo);

	@Select("SELECT * FROM NOTICE_TBL ORDER BY NOTICE_NO DESC")
//	@Results({
//		  @Result(property="noticeNo",		   column="NOTICE_NO")
//		, @Result(property="noticeSubject",    column="NOTICE_SUBJECT")
//		, @Result(property="noticeContent",	   column="NOTICE_CONTENT")
//		, @Result(property="noticeWriter", 	   column="NOTICe_WRITER")
//		, @Result(property="noticeDate",       column="NOTICE_DATE")
//		, @Result(property="updateDate", 	   column="UPDATE_DATE")
//		, @Result(property="noticeFilename",   column="NOTICE_FILENAME")
//		, @Result(property="noticeFileRename", column="NOTICE_FILERENAME")
//		, @Result(property="noticeFilepath",   column="NOTICE_FILEPATH")
//		, @Result(property="noticeFileLength", column="NOTICE_FILELENGTH")
//	})
	List<NoticeVO> selectNoticeList(RowBounds rowBounds);

	@Select("SELECT * FROM NOTICE_TBL WHERE NOTICE_NO = #{noticeNo }")
	NoticeVO selectOneByNo(Integer noticeNo);
	
}
