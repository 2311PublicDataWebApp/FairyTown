package com.ajoo.boottwo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AjooBootTwoApplication {

	public static void main(String[] args) {
		SpringApplication.run(AjooBootTwoApplication.class, args);
	}
	
}
