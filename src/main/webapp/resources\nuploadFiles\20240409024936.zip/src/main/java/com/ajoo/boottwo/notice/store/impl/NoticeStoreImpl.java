package com.ajoo.boottwo.notice.store.impl;

import org.springframework.stereotype.Repository;

import com.ajoo.boottwo.notice.store.NoticeStore;

public class NoticeStoreImpl {

	
	
}
