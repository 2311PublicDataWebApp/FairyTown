package com.ajoo.boottwo.notice.service;

import java.util.List;

import com.ajoo.boottwo.domain.vo.NoticeVO;
import com.ajoo.boottwo.domain.vo.PageInfo;

public interface NoticeService {

	int insertNotice(NoticeVO notice);

	int updateNotice(NoticeVO notice);

	int deleteNotice(Integer noticeNo);

	NoticeVO selectOneByNo(Integer noticeNo);

	List<NoticeVO> selectNoticeList(PageInfo pi);

}
