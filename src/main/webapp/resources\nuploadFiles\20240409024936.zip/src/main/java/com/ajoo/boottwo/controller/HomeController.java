package com.ajoo.boottwo.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController // API서버로 만듦.
public class HomeController {

	
	@RequestMapping(value="/home.do", method=RequestMethod.GET)
	public String home() {
		return "Hello Spring Boot";
	}
}
