package com.ajoo.boottwo.notice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.ajoo.boottwo.domain.vo.NoticeVO;
import com.ajoo.boottwo.domain.vo.PageInfo;
import com.ajoo.boottwo.notice.service.NoticeService;

@Controller
public class NoticeController {

	@Autowired
	private NoticeService nService;
	
//	@RequestMapping(value="/notice/insert", method=RequestMethod.GET)
	@GetMapping("/notice/insert")
	public String showWriteForm() {
		return "notice/write";
	}
	
	@PostMapping("/notice/insert")
	public String insertNotice(NoticeVO notice) {
		int result = nService.insertNotice(notice);
		return "redirect:/notice/list";
	}
	
	@GetMapping("/notice/modify")
	public String showModifyView(Model model, Integer noticeNo) {
		NoticeVO notice = nService.selectOneByNo(noticeNo);
		model.addAttribute("notice", notice);
		return "notice/modify";
	}
	
	@PostMapping("/notice/modify")
	public String updateNotice(NoticeVO notice) {
		int result = nService.updateNotice(notice);		
		return "redirect:/notice/detail?noticeNo="+notice.getNoticeNo();
	}
	
	@GetMapping("notice/delete")
	public String deleteNotice(Integer noticeNo) {
		int result = nService.deleteNotice(noticeNo);
		return "redirect:/notice/list"; 
	}
	
	@GetMapping("/notice/list")
	public String showNoticeList(Model model
			, @RequestParam(value="page", required=false, defaultValue="1") Integer currentPage) {
		int boardLimit = 10;
		int totalCount = 228;
		PageInfo pi = new PageInfo(currentPage, totalCount, boardLimit);
		List<NoticeVO> nList = nService.selectNoticeList(pi);
		model.addAttribute("nList", nList);
		model.addAttribute("pi", pi);
		return "notice/list";
	}
	
	@GetMapping("/notice/detail")
	public String showNoticeByNo(Model model
			, Integer noticeNo) {
		NoticeVO notice = nService.selectOneByNo(noticeNo);
		model.addAttribute("notice", notice);
		return "notice/detail";
	}
	
	
}
