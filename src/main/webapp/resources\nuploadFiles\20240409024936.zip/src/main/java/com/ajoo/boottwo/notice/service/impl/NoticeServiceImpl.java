package com.ajoo.boottwo.notice.service.impl;

import java.util.List;

import org.apache.ibatis.session.RowBounds;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ajoo.boottwo.domain.vo.NoticeVO;
import com.ajoo.boottwo.domain.vo.PageInfo;
import com.ajoo.boottwo.notice.service.NoticeService;
import com.ajoo.boottwo.notice.store.NoticeStore;

@Service
public class NoticeServiceImpl implements NoticeService{

	@Autowired
	private NoticeStore nStore;
	
	@Override
	public int insertNotice(NoticeVO notice) {
		int result = nStore.insertNotice(notice);
		return result;
	}

	@Override
	public int updateNotice(NoticeVO notice) {
		int result = nStore.updateNotice(notice);
		return result;
	}

	@Override
	public int deleteNotice(Integer noticeNo) {
		int result = nStore.deleteNotice(noticeNo);
		return result;
	}

	@Override
	public List<NoticeVO> selectNoticeList(PageInfo pi) {
		int limit = pi.getBoardLimit();
		int offset = (pi.getCurrentPage() - 1) * pi.getBoardLimit();
		RowBounds rowBounds = new RowBounds(offset, limit);
		List<NoticeVO> nList = nStore.selectNoticeList(rowBounds);
		return nList;
	}

	@Override
	public NoticeVO selectOneByNo(Integer noticeNo) {
		NoticeVO notice = nStore.selectOneByNo(noticeNo);
		return notice;
	}

}
